----------------------------------------------
++++++++++++++++++++++++++++++++++++++++++++++
----------------------------------------------
YELP ACADEMIC DATASET ANALYTICS TOOL README
----------------------------------------------
++++++++++++++++++++++++++++++++++++++++++++++
----------------------------------------------


Here is the initial window. 6 functional options are presented as well as quit path


== YELP ACADEMIC DATASET ANALYTICS TOOL ==
Choose one of the following options below (e.g. '3'):
>>OPTION 1: Categorical breakdown by city of stars by review count
>>OPTION 2: Categorical breakdown by city of reviews by review count
>>OPTION 3: Average rating by franchise
>>OPTION 4: Average rating across all users
>>OPTION 5: Categorical count distribution by average stars for all users
>>OPTION 6: Average stars by year for a particular user
>>QUIT: Quit application



>>OPTION 1:
>>>>Enter a city name: Here the user will need to input a city name that exists in the Yelp Business Table

ex. Las Vegas, Phoenix, Tempe, Chandler, Henderson, Scottsdale, Madison, Queen Creek

>>OPTION 2:
>>>>Enter a city name: Here the user will need to input a city name that exists in the Yelp Business Table

ex. Las Vegas, Phoenix, Tempe, Chandler, Henderson, Scottsdale, Madison, Queen Creek

>>OPTION 3:
>>>>Enter a franchise name: Here the user will need to input a franchise name that exists in the Yelp Business Table

ex. Yard House, Taco Bell, Subway, Starbucks, Walmart, Sprint, In-N-Out Burger

>>OPTION 4:
>>>>no input required

>>OPTION 5:
>>>>no input required

>>OPTION 6:
>>>>Enter user_id: here the user will need to input the user_id of a user found in the Users Table

ex. kGgAARL2UmvCcTRfiscjug, pz97SxRe1Vk-5_K6EB9OSA

>>quit
>>>>application will quit